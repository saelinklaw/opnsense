#!/bin/sh

chmod 600 /usr/local/etc/monitrc
